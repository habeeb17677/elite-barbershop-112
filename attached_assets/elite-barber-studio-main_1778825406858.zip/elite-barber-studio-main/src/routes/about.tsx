import { createFileRoute, Link } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { Award, Sparkles, Heart, Shield, Accessibility, Coffee, Baby, CreditCard } from "lucide-react";
import g3 from "@/assets/gallery-3.jpg";

export const Route = createFileRoute("/about")({
  component: () => (<Layout><About /></Layout>),
  head: () => ({
    meta: [
      { title: "About — Elite Barbershop Tulsa" },
      { name: "description", content: "Learn about Elite Barbershop in Tulsa, OK — master barbers, premium service, welcoming atmosphere." },
    ],
  }),
});

function About() {
  const values = [
    { Icon: Award, title: "Master Craft", text: "Years of training, sharpened daily." },
    { Icon: Sparkles, title: "Premium Experience", text: "Luxury atmosphere, every visit." },
    { Icon: Heart, title: "Customer First", text: "Your comfort is our priority." },
    { Icon: Shield, title: "Hygiene Standards", text: "Sanitized tools, fresh capes." },
  ];
  const amenities = [
    { Icon: Accessibility, label: "Wheelchair Accessible Entrance & Parking" },
    { Icon: Coffee, label: "Complimentary Beverages" },
    { Icon: Baby, label: "Good For Kids" },
    { Icon: CreditCard, label: "NFC Mobile Payment" },
  ];

  return (
    <>
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-up">
            <span className="text-xs uppercase tracking-widest text-gold">Our Story</span>
            <h1 className="mt-3 text-4xl md:text-6xl font-bold">About <span className="gradient-gold">Elite Barbershop</span></h1>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              At Elite Barbershop, we blend old-school barbering tradition with modern style. Our master barbers take pride in every cut, every shave, every detail — delivering a grooming experience that's as refined as it is relaxing.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              From precision fades to traditional hot towel shaves, we treat every client like royalty. Walk in as a guest, leave as family.
            </p>
            <Link to="/booking" className="mt-8 inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold transition-all">
              Book Your Visit
            </Link>
          </div>
          <div className="relative">
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-elegant">
              <img src={g3} alt="Stylish client at Elite Barbershop" loading="lazy" width={1024} height={1024} className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -left-6 glass p-5 rounded-2xl hidden sm:block">
              <div className="text-3xl font-display gradient-gold">5★</div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">Rated Service</div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-xs uppercase tracking-widest text-gold">Why Choose Us</span>
            <h2 className="mt-3 text-3xl md:text-5xl font-bold">Quality In <span className="gradient-gold">Every Detail</span></h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {values.map(({ Icon, title, text }) => (
              <div key={title} className="p-7 rounded-2xl glass text-center hover:-translate-y-1 transition-all">
                <div className="w-14 h-14 mx-auto rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-display text-lg">{title}</h3>
                <p className="text-sm text-muted-foreground mt-2">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs uppercase tracking-widest text-gold">What's Included</span>
            <h2 className="mt-3 text-3xl md:text-5xl font-bold">Comfort &amp; <span className="gradient-gold">Convenience</span></h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {amenities.map(({ Icon, label }) => (
              <div key={label} className="flex items-center gap-4 p-5 rounded-xl glass">
                <div className="w-11 h-11 rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <span className="font-medium">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
