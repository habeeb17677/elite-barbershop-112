import { createFileRoute } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { useState, FormEvent } from "react";
import emailjs from "@emailjs/browser";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { Calendar, Loader2 } from "lucide-react";
import { SERVICE_NAMES } from "@/lib/services";

export const Route = createFileRoute("/booking")({
  component: () => (<Layout><Booking /><Toaster theme="dark" position="top-center" /></Layout>),
  head: () => ({
    meta: [
      { title: "Book Appointment — Elite Barbershop Tulsa" },
      { name: "description", content: "Book your appointment at Elite Barbershop in Tulsa, OK. Quick online booking." },
    ],
  }),
});

const SERVICE_ID = "service_ey8z0ot";
const TEMPLATE_ID = "template_r84lf7q";
const PUBLIC_KEY = "tpbXsl2M-KUtJ5aUk";

function Booking() {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    full_name: "", phone: "", service: "", date: "", time: "", notes: "",
  });

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.full_name.trim() || !form.phone.trim() || !form.service || !form.date || !form.time) {
      toast.error("Please fill in all required fields.");
      return;
    }
    if (!/^[\d\s+()-]{7,}$/.test(form.phone)) {
      toast.error("Please enter a valid phone number.");
      return;
    }
    setLoading(true);
    try {
      await emailjs.send(SERVICE_ID, TEMPLATE_ID, {
        full_name: form.full_name,
        phone: form.phone,
        service: form.service,
        date: form.date,
        time: form.time,
        notes: form.notes || "—",
        to_business: "Elite Barbershop",
      }, { publicKey: PUBLIC_KEY });
      toast.success("Appointment request sent successfully. We will contact you shortly.");
      setForm({ full_name: "", phone: "", service: "", date: "", time: "", notes: "" });
    } catch (err) {
      console.error(err);
      toast.error("Unable to send booking request. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const inputCls = "w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-gold focus:outline-none focus:ring-2 focus:ring-gold/30 transition-all text-foreground placeholder:text-muted-foreground";

  return (
    <section className="py-16 md:py-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <span className="text-xs uppercase tracking-widest text-gold">Reserve Your Chair</span>
          <h1 className="mt-3 text-4xl md:text-6xl font-bold">Book An <span className="gradient-gold">Appointment</span></h1>
          <p className="mt-4 text-muted-foreground">Tell us when you'd like to come in — we'll confirm shortly.</p>
        </div>
        <form onSubmit={onSubmit} className="glass rounded-3xl p-6 sm:p-10 space-y-5">
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Full Name *</label>
              <input type="text" required value={form.full_name} onChange={update("full_name")} className={inputCls} placeholder="John Doe" />
            </div>
            <div>
              <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Phone *</label>
              <input type="tel" required value={form.phone} onChange={update("phone")} className={inputCls} placeholder="+1 555 123 4567" />
            </div>
          </div>
          <div>
            <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Service *</label>
            <select required value={form.service} onChange={update("service")} className={inputCls}>
              <option value="">Select a service…</option>
              {SERVICE_NAMES.map((s) => (<option key={s} value={s}>{s}</option>))}
            </select>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Preferred Date *</label>
              <input type="date" required value={form.date} onChange={update("date")} className={inputCls} min={new Date().toISOString().split("T")[0]} />
            </div>
            <div>
              <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Preferred Time *</label>
              <input type="time" required value={form.time} onChange={update("time")} className={inputCls} min="08:00" max="20:00" />
            </div>
          </div>
          <div>
            <label className="block text-sm uppercase tracking-widest text-muted-foreground mb-2">Notes</label>
            <textarea rows={4} value={form.notes} onChange={update("notes")} className={inputCls} placeholder="Anything we should know?" />
          </div>
          <button type="submit" disabled={loading} className="w-full inline-flex items-center justify-center gap-2 px-7 py-4 rounded-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold transition-all disabled:opacity-60 disabled:cursor-not-allowed">
            {loading ? (<><Loader2 className="w-5 h-5 animate-spin" /> Sending…</>) : (<><Calendar className="w-5 h-5" /> Request Appointment</>)}
          </button>
          <p className="text-xs text-center text-muted-foreground">We're open daily 8AM – 8PM. Walk-ins also welcome.</p>
        </form>
      </div>
    </section>
  );
}
