import { createFileRoute } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { Phone, MapPin, Clock, Navigation } from "lucide-react";

export const Route = createFileRoute("/contact")({
  component: () => (<Layout><Contact /></Layout>),
  head: () => ({
    meta: [
      { title: "Contact — Elite Barbershop Tulsa" },
      { name: "description", content: "Visit Elite Barbershop at 5635 S Mingo Rd Unit K, Tulsa, OK 74146. Call +1 539-367-2000." },
    ],
  }),
});

const ADDRESS = "5635 S Mingo Rd Unit K, Tulsa, OK 74146";
const MAPS_DIR = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(ADDRESS)}`;
const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`;

function Contact() {
  return (
    <>
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14 animate-fade-up">
            <span className="text-xs uppercase tracking-widest text-gold">Get In Touch</span>
            <h1 className="mt-3 text-4xl md:text-6xl font-bold">Visit <span className="gradient-gold">The Shop</span></h1>
            <p className="mt-4 text-muted-foreground">Stop by, call ahead, or get directions — we're easy to find.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-5 mb-10">
            <a href="tel:+15393672000" className="group p-7 rounded-2xl glass hover:border-gold/40 transition-all">
              <div className="w-12 h-12 rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4 group-hover:bg-gradient-gold group-hover:text-primary-foreground transition-all">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="text-xs uppercase tracking-widest text-muted-foreground">Call Us</h3>
              <p className="mt-2 font-display text-xl">+1 539-367-2000</p>
            </a>
            <div className="p-7 rounded-2xl glass">
              <div className="w-12 h-12 rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="text-xs uppercase tracking-widest text-muted-foreground">Address</h3>
              <p className="mt-2 font-display text-lg leading-snug">5635 S Mingo Rd Unit K<br />Tulsa, OK 74146</p>
            </div>
            <div className="p-7 rounded-2xl glass">
              <div className="w-12 h-12 rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold mb-4">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="text-xs uppercase tracking-widest text-muted-foreground">Business Hours</h3>
              <p className="mt-2 font-display text-lg">Open Daily<br />8:00 AM – 8:00 PM</p>
            </div>
          </div>

          <div className="rounded-3xl overflow-hidden glass shadow-elegant">
            <div className="aspect-[16/10] md:aspect-[21/9] w-full">
              <iframe
                title="Elite Barbershop location"
                src={MAPS_EMBED}
                width="100%" height="100%"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            </div>
            <div className="p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t border-border">
              <div className="text-sm text-muted-foreground flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gold" /> {ADDRESS}
              </div>
              <a href={MAPS_DIR} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-gradient-gold text-primary-foreground font-semibold hover:shadow-gold transition-all">
                <Navigation className="w-4 h-4" /> Get Directions
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
