import { createFileRoute } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";
import hero from "@/assets/hero-barbershop.jpg";

export const Route = createFileRoute("/gallery")({
  component: () => (<Layout><Gallery /></Layout>),
  head: () => ({
    meta: [
      { title: "Gallery — Elite Barbershop Tulsa" },
      { name: "description", content: "Recent cuts, shaves and styles from Elite Barbershop in Tulsa, OK." },
    ],
  }),
});

function Gallery() {
  const images = [g1, g3, hero, g2, g4, g1, g3, g2];
  return (
    <section className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14 animate-fade-up">
          <span className="text-xs uppercase tracking-widest text-gold">Our Work</span>
          <h1 className="mt-3 text-4xl md:text-6xl font-bold">The <span className="gradient-gold">Gallery</span></h1>
          <p className="mt-4 text-muted-foreground">A glimpse into the craft — fresh cuts, sharp lines and timeless style.</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {images.map((src, i) => (
            <div key={i} className={`overflow-hidden rounded-xl group ${i % 5 === 0 ? "row-span-2 aspect-[1/2]" : "aspect-square"}`}>
              <img src={src} alt={`Gallery ${i + 1}`} loading="lazy" width={1024} height={1024} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
