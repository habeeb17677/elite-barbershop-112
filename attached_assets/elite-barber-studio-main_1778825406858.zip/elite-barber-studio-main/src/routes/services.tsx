import { createFileRoute, Link } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { Scissors, ArrowRight } from "lucide-react";
import { SERVICES } from "@/lib/services";

export const Route = createFileRoute("/services")({
  component: () => (<Layout><Services /></Layout>),
  head: () => ({
    meta: [
      { title: "Services — Elite Barbershop Tulsa" },
      { name: "description", content: "Full menu of premium barbering services at Elite Barbershop Tulsa: haircuts, fades, shaves, beard care and more." },
    ],
  }),
});

function Services() {
  return (
    <section className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14 animate-fade-up">
          <span className="text-xs uppercase tracking-widest text-gold">The Menu</span>
          <h1 className="mt-3 text-4xl md:text-6xl font-bold">Our <span className="gradient-gold">Services</span></h1>
          <p className="mt-4 text-muted-foreground">From classic cuts to traditional shaves — every service crafted with precision.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((s) => (
            <div key={s.name} className="group p-6 rounded-2xl glass hover:border-gold/40 transition-all hover:-translate-y-1">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-gold/10 border border-gold/30 flex items-center justify-center text-gold group-hover:bg-gradient-gold group-hover:text-primary-foreground transition-all">
                  <Scissors className="w-5 h-5" />
                </div>
                <span className="text-gold font-semibold">{s.price}</span>
              </div>
              <h3 className="text-xl font-display">{s.name}</h3>
              <p className="text-sm text-muted-foreground mt-2">{s.desc}</p>
              <Link to="/booking" className="mt-4 text-sm text-muted-foreground hover:text-gold inline-flex items-center gap-1">
                Book this service <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ))}
        </div>
        <p className="text-center text-xs text-muted-foreground mt-10">* Prices are starting estimates — final pricing confirmed in-shop.</p>
      </div>
    </section>
  );
}
